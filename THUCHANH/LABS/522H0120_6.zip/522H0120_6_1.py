import matplotlib.pyplot as plt
import numpy as np
from scipy.stats import norm

def plot_cdf_normal(mu, sigma):
    # Tạo một dãy giá trị của biến ngẫu nhiên X
    X = np.linspace(mu - 4*sigma, mu + 4*sigma, 100)

    # Tính xác suất của phân phối tích lũy cho mỗi giá trị của X
    probabilities = norm.cdf(X, mu, sigma)

    # Vẽ đồ thị
    plt.plot(X, probabilities)
    plt.xlabel('Giá trị của biến ngẫu nhiên X')
    plt.ylabel('Xác suất CDF(X)')
    plt.title(f'Phân phối tích lũy của biến ngẫu nhiên X (μ={mu}, σ={sigma})')
    plt.grid(True)
    plt.show()

# Gọi hàm plot_cdf_normal với các tham số μ và σ
plot_cdf_normal(0, 1.5)

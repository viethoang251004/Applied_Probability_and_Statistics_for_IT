from scipy.stats import norm

mu = 10
sigma = 1

# Tính xác suất P(9 ≤ X ≤ 12)
probability = norm.cdf(12, mu, sigma) - norm.cdf(9, mu, sigma)

print(probability)

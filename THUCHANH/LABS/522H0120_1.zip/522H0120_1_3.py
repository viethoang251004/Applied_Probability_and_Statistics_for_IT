import math

num_arrangements = math.factorial(10) / (math.factorial(4) * math.factorial(3) * math.factorial(2) * math.factorial(1))

print("Số cách sắp xếp khác nhau:", num_arrangements)

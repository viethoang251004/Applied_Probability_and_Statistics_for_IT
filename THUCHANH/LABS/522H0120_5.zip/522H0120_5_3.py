import matplotlib.pyplot as plt
import numpy as np
from scipy.stats import geom

# (a)
p = 0.4
x = 3

probability = geom.pmf(x, p)
print("(a)", probability)

# (b)
p = 0.4
X = np.arange(1, 11)
probabilities = geom.pmf(X, p)

plt.bar(X, probabilities)
plt.xlabel('Số lần bắn trước khi trúng đích')
plt.ylabel('Xác suất')
plt.title('(b) Phân phối xác suất của số lần bắn trước khi trúng đích')
plt.show()
import matplotlib.pyplot as plt
import numpy as np
from scipy.stats import binom

# (a)
n = 5
p = 0.1
x = 2

probability = binom.pmf(x, n, p)
print("(a)", probability)

#(b)
n = 5
p = 0.1
X = np.arange(0, n+1)
probabilities = binom.pmf(X, n, p)

plt.bar(X, probabilities)
plt.xlabel('Số lượng máy hỏng')
plt.ylabel('Xác suất')
plt.title('(b) Phân phối xác suất của số lượng máy hỏng')
plt.show()
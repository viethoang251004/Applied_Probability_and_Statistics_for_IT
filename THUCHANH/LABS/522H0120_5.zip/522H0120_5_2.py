import matplotlib.pyplot as plt
import numpy as np
from scipy.stats import poisson

# (a)
lmbda = 3
x = 2

probability = poisson.pmf(x, lmbda)
print("(a)", probability)

# (b)
lmbda = 3
X = np.arange(1, 6)
probabilities = poisson.pmf(X, lmbda)

plt.bar(X, probabilities)
plt.xlabel('Số lượng cuộc gọi')
plt.ylabel('Xác suất')
plt.title('(b) Phân phối xác suất của số lượng cuộc gọi')
plt.show()
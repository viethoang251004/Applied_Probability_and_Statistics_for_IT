from fractions import Fraction
import itertools
import random

# Hàm cross để tạo tập hợp kết hợp các phần tử từ hai tập hợp A và B
def cross(A, B):
    return {a + b for a in A for b in B}

urn = cross('W', '12345') | cross('B', '12') | cross('R', '123')

# Danh sách U3 chứa tất cả các cách chọn 3 viên bi từ trong bình urn
U3 = list(itertools.combinations(urn, 3))
len_U3 = len(U3)

# a/ Tính xác suất thực nghiệm cho sự kiện "Cả ba viên cùng màu"
def simulator_all_3_balls_same_color(n):
    count = 0
    for i in range(n):
        round = random.sample(urn, 3)
        s = {round[0][0], round[1][0], round[2][0]}
        if len(s) == 1:
            count += 1
    return count / n

# b/ Tính xác suất thực nghiệm cho sự kiện "Cả ba viên đều khác màu nhau"
def simulator_all_3_balls_different_colors(n):
    count = 0
    for i in range(n):
        round = random.sample(urn, 3)
        s = {round[0][0], round[1][0], round[2][0]}
        if len(s) == 3:
            count += 1
    return count / n

# c/ Tính xác suất thực nghiệm cho sự kiện "Chỉ có hai viên cùng màu"
def simulator_exactly_2_balls_same_color(n):
    count = 0
    for i in range(n):
        round = random.sample(urn, 3)
        s = {round[0][0], round[1][0], round[2][0]}
        if len(s) == 2:
            count += 1
    return count / n

# d/ Tính xác suất thực nghiệm cho sự kiện "Được 2 bi đỏ và 1 bi trắng"
def simulator_2_red_1_white(n):
    count = 0
    for i in range(n):
        round = random.sample(urn, 3)
        red_count = sum(ball[0] == 'R' for ball in round)
        white_count = sum(ball[0] == 'W' for ball in round)
        if red_count == 2 and white_count == 1:
            count += 1
    return count / n

# e/ Liệt kê các trường hợp 3 bi đều màu trắng
def list_all_white_cases():
    white_cases = []
    for u in U3:
        s = {u[0][0], u[1][0], u[2][0]}
        if len(s) == 1 and 'W' in s:
            white_cases.append(u)
    return white_cases

print("a/ Xác suất thực nghiệm:", simulator_all_3_balls_same_color(10000))
print("b/ Xác suất thực nghiệm:", simulator_all_3_balls_different_colors(10000))
print("c/ Xác suất thực nghiệm:", simulator_exactly_2_balls_same_color(10000))
print("d/ Xác suất thực nghiệm:", simulator_2_red_1_white(10000))
print("e/ Các trường hợp 3 bi đều màu trắng:", list_all_white_cases())

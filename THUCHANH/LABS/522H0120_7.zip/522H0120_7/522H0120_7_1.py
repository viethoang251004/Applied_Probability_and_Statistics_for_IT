import random
import itertools

S = list(itertools.product({1,2,3,4,5,6},{1,2,3,4,5,6}))
print(S)
count = 0

# cau a
print("a/ Hai vien giong nhau")
print("-- Ly thuyet")

for s in S:
    if s[0] == s[1]:
        count += 1

print("A =", count)
print("P =", count, "/", len(S), "=", count/len(S))
print("---------------------------------------------")
print("-- Thuc nghiem")
def simulator_both_dices_are_the_same(n):
    count = 0
    for i in range(n):
        dice1 = random.randint(1,6)
        dice2 = random.randint(1,6)
        if dice1 == dice2:
            count += 1
    return count/n

print(100, simulator_both_dices_are_the_same(100))

# cau b
print("b/ Hai vien khac nhau")
print("-- Ly thuyet")
for s in S:
    if s[0] != s[1]:
        count += 1
    
print("A =", count)
print("P = ", count, "/", len(S), "=", count/len(S))
print("---------------------------------------------")
print("-- Thuc nghiem")
def simulator_both_dices_are_different(y):
    count = 0
    for x in range(y):
        dice1 = random.randint(1,6)
        dice2 = random.randint(1,6)
        if dice1 != dice2:
            count += 1
    return count/y

print(1000, simulator_both_dices_are_different(1000))

# cau c
print("c/ Hai vien cung chan")
print("-- Ly thuyet")
for s in S:
    if s[0] % 2 == 0 and s[1] % 2 ==0:
        count += 1
    
print("A =", count)
print("P = ", count, "/", len(S), "=", count/len(S))
print("---------------------------------------------")
print("-- Thuc nghiem")
def simulator_both_dices_are_even(y): # type: ignore
    count = 0
    for x in range(y):
        dice1 = random.randint(1,6)
        dice2 = random.randint(1,6)
        if dice1 % 2 == 0 and dice2 % 2 == 0:
            count += 1
    return count/y

print(10000, simulator_both_dices_are_even(10000))

# cau d
print("d/ Hai vien cung le")
print("-- Ly thuyet")
for s in S:
    if s[0] % 2 == 0 and s[1] % 2 ==0:
        count += 1
    
print("A =", count)
print("P = ", count, "/", len(S), "=", count/len(S))
print("---------------------------------------------")
print("-- Thuc nghiem")
def simulator_both_dices_are_even(y):
    count = 0
    for x in range(y):
        dice1 = random.randint(1,6)
        dice2 = random.randint(1,6)
        if dice1 % 2 == 0 and dice2 % 2 == 0:
            count += 1
    return count/y

print(10000, simulator_both_dices_are_even(10000))

# cau e
print("e/ Mot vien chan va mot vien le")
print("-- Ly thuyet")
for s in S:
    if (s[0] % 2 != 0 and s[1] % 2 == 0) or (s[0] % 2 == 0 and s[1] % 2 != 0):
        count += 1
    
print("A =", count)
print("P = ", count, "/", len(S), "=", count/len(S))
print("---------------------------------------------")
print("-- Thuc nghiem")
def simulator_one_dice_is_even_and_one_dice_is_odd(x): # type: ignore
    count = 0
    for x in range(x):
        dice1 = random.randint(1,6)
        dice2 = random.randint(1,6)
        if (dice1 % 2 != 0 and dice2 % 2 == 0) or (dice1 % 2 == 0 and dice2 % 2 != 0):
            count += 1
    return count/x

print(1000, simulator_one_dice_is_even_and_one_dice_is_odd(1000))

# cau f
print("f/ Hai vien cung ra 6")
print("-- Ly thuyet")
for s in S:
    if s[0] == 6 and s[1] == 6:
        count += 1
    
print("A =", count)
print("P = ", count, "/", len(S), "=", count/len(S))
print("---------------------------------------------")
print("-- Thuc nghiem")
def simulator_one_dice_is_even_and_one_dice_is_odd(x): # type: ignore
    count = 0
    for x in range(x):
        dice1 = random.randint(1,6)
        dice2 = random.randint(1,6)
        if dice1 == 6 and dice2 == 6:
            count += 1
    return count/x

print(1000, simulator_one_dice_is_even_and_one_dice_is_odd(1000))

# cau g
print("g/ Hai vien co tong so nut lon hon 10")
print("-- Ly thuyet")
for s in S:
    if s[0] + s[1] > 10:
        count += 1
    
print("A =", count)
print("P = ", count, "/", len(S), "=", count/len(S))
print("---------------------------------------------")
print("-- Thuc nghiem")
def simulator_one_dice_is_even_and_one_dice_is_odd(x):
    count = 0
    for x in range(x):
        dice1 = random.randint(1,6)
        dice2 = random.randint(1,6)
        if dice1 + dice2 > 10:
            count += 1
    return count/x

print(1000, simulator_one_dice_is_even_and_one_dice_is_odd(1000))
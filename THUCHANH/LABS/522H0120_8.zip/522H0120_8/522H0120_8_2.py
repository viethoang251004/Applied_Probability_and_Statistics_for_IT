import pandas as pd

# (a)
df = pd.read_csv("population.csv")

# (b)
print("b)", df.head(5))

# (c)
statistics_df = df.groupby("Year")["Value"].agg(["count", "mean", "std", "min", "max"])

# Rename the column
statistics_df = statistics_df.rename(columns={"count": "Count"})

print("c)", statistics_df)

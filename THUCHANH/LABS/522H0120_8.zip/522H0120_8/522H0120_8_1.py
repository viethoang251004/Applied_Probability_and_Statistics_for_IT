import pandas as pd

# (a)
df = pd.read_csv('iris.csv')

# (b)
print("b)", df.head())

# (c)
numeric_df = df.drop('species', axis=1)

# Compute count, mean, standard deviation, min, and max
count = numeric_df.count()
mean = numeric_df.sum() / count
std = (numeric_df ** 2).sum() / count - mean ** 2
std = std ** 0.5
minimum = numeric_df.min()
maximum = numeric_df.max()

# Create a DataFrame to display the results
result_df = pd.DataFrame({'count': count, 'mean': mean, 'std': std, 'min': minimum, 'max': maximum})

print("c)", result_df)